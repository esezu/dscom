<?php
namespace app\p\controller;
use think\Cache;
use think\Db;
use think\Controller;
use think\Session;
class BaseController extends Controller{
	protected function _initialize(){ 
	}
	 
}
