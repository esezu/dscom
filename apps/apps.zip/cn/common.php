<?php
//admin模块公共函数

/**
 * 管理员操作日志
 * @param  [type] $data [description]
 * @return [type]       [description]
 */
function addlog($content_id=''){
 
}
